# Todo
- #3: Build admin panel UI for managing plans
- #4: Add API endpoints for CRUD operations on plans
- #5: Connect admin panel to backend and make plans dynamic
- #6: Add VPS hosting category and plans
- #7: Add Web hosting category and plans
