
DELETE FROM plans WHERE category_id = 4;
DELETE FROM categories WHERE id = 4;
