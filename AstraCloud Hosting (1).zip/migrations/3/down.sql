
DROP INDEX idx_reviews_created_at;
DROP INDEX idx_reviews_rating;
DROP TABLE reviews;
