
DROP INDEX idx_plans_display_order;
DROP INDEX idx_plans_category_id;
DROP TABLE plans;
DROP TABLE categories;
